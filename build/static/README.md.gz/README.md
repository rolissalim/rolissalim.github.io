# How to cal
SIMPAN FILE" IMAEG DLL DIDALAM FOLDER STATIC LOADED FROM URL

# Example
cara panggil
<img src="/static/logo.png">